package repositorio;

import dominio.Atividade;

import java.util.ArrayList;
import java.util.List;

public class ListaAtividades implements RepositorioAtividades {
    private List<Atividade> atividades = new ArrayList<>();

    @Override
    public void adicionar(Atividade atividade) {
        atividades.add(atividade);
    }

    @Override
    public boolean remover(int index) {
        if (index >= 0 && index < atividades.size()) {
            if (atividades.get(index).isConcluida()) {
                System.out.println("Erro: Atividade já concluída não pode ser removida.");
                return false;
            }
            atividades.remove(index);
            return true;
        }
        return false;
    }

    @Override
    public boolean concluir(int index) {
        if (index >= 0 && index < atividades.size()) {
            Atividade atividade = atividades.get(index);
            if (atividade.isConcluida()) {
                System.out.println("Erro: Atividade já está concluída.");
                return false;
            }
            atividade.marcarComoConcluida();
            return true;
        }
        return false;
    }

    @Override
    public List<Atividade> listar() {
        return atividades;
    }
}