package repositorio;

import dominio.Atividade;
import java.util.List;

public interface RepositorioAtividades {
    void adicionar(Atividade atividade);
    boolean remover(int index);
    boolean concluir(int index);
    List<Atividade> listar();
}