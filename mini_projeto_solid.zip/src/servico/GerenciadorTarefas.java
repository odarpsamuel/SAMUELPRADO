package servico;

import dominio.Atividade;
import repositorio.RepositorioAtividades;

import java.util.List;

public class GerenciadorTarefas {
    private RepositorioAtividades repositorio;

    public GerenciadorTarefas(RepositorioAtividades repositorio) {
        this.repositorio = repositorio;
    }

    public void adicionar(String descricao) {
        repositorio.adicionar(new Atividade(descricao));
    }

    public boolean remover(int index) {
        return repositorio.remover(index);
    }

    public boolean concluir(int index) {
        return repositorio.concluir(index);
    }

    public List<Atividade> listar() {
        return repositorio.listar();
    }
}