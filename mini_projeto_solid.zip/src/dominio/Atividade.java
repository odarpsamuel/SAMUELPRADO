package dominio;

public class Atividade {
    private String descricao;
    private boolean concluida;

    public Atividade(String descricao) {
        this.descricao = descricao;
        this.concluida = false;
    }

    public String getDescricao() {
        return descricao;
    }

    public boolean isConcluida() {
        return concluida;
    }

    public void marcarComoConcluida() {
        this.concluida = true;
    }

    @Override
    public String toString() {
        return descricao + (concluida ? " - Concluída" : " - Pendente");
    }
}