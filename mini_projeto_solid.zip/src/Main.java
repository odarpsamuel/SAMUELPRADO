import dominio.Atividade;
import repositorio.ListaAtividades;
import servico.GerenciadorTarefas;

import java.util.Scanner;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GerenciadorTarefas gerenciador = new GerenciadorTarefas(new ListaAtividades());

        while (true) {
            System.out.println("\n--- Gerenciador de Atividades ---");
            System.out.println("1. Adicionar Atividade");
            System.out.println("2. Remover Atividade");
            System.out.println("3. Marcar como Concluída");
            System.out.println("4. Listar Atividades");
            System.out.println("5. Sair");
            System.out.print("Escolha: ");

            String opcao = scanner.nextLine();
            switch (opcao) {
                case "1":
                    System.out.print("Descrição: ");
                    String desc = scanner.nextLine();
                    gerenciador.adicionar(desc);
                    System.out.println("✔ Atividade adicionada.");
                    break;
                case "2":
                    listar(gerenciador.listar());
                    System.out.print("Número da atividade: ");
                    int iRemover = Integer.parseInt(scanner.nextLine()) - 1;
                    gerenciador.remover(iRemover);
                    break;
                case "3":
                    listar(gerenciador.listar());
                    System.out.print("Número da atividade: ");
                    int iConcluir = Integer.parseInt(scanner.nextLine()) - 1;
                    gerenciador.concluir(iConcluir);
                    break;
                case "4":
                    listar(gerenciador.listar());
                    break;
                case "5":
                    System.out.println("Encerrando...");
                    return;
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }

    public static void listar(List<Atividade> atividades) {
        if (atividades.isEmpty()) {
            System.out.println("Nenhuma atividade cadastrada.");
        } else {
            int i = 1;
            for (Atividade a : atividades) {
                System.out.println(i++ + ". " + a);
            }
        }
    }
}